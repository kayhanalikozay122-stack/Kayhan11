# guille_gangsv2 
https://discord.gg/nwS6PWxZEs
https://discord.gg/nwS6PWxZEs

## Download & Installation (If you need a more complete gang system, check out https://store.rcore.cz/gangsystem#package:4913168 made by my Rcore mates ♥)

### Using [fvm](https://github.com/qlaffont/fvm-installer)

fvm install --save --folder=local guillerp8/guille_gangsv2
### Using [Git](https://git-scm.com/downloads)

cd resources
git clone https://github.com/guillerp8/guille_gangsv2 [local]/guille_gangsv2
### Manually
- Download https://github.com/guillerp8/guille_gangsv2/archive/master.zip
- Put it in the `[local]` directory

# Commands

- /creategang
- /modifygangs
- /setgang + id + gang + rank
- /setgangmember + id + rank (Only works if you are gang boss to add members to your gang)
- Interaction menu at f11
